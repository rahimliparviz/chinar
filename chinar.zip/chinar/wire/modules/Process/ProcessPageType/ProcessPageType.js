$(document).ready(function() {
	$("#templates_id").change(function() {
		$("#template_filter_form").submit();
	 }); 
});
